#include "get_path.h"

int pid;
struct pathelement *pathlist;

int sh(int argc, char **argv, char **envp);
char *which(char *command);
void where(char *command);
void list(char *dir);
void my_printenv(char **envp);
void my_setenv(char **envp);
void my_alias(char **envp);
void my_cd(const char *cd_to);
char * my_pwd();
void execF(char** args, char *path, char **envp);
int cmpWithWildCard(char *str1, char *str2);

#define PROMPTMAX 32
#define MAXARGS 10
#define MAX_CANON 10

void free_env();

typedef struct history{
	  char *cmdline;
	  struct history *next;
} hist;

void printHist(int size);
void freeHist();

typedef struct alias{
	  char *cmd;
	  char *cmdline;
	  struct alias *next;
} as;

void creatAs(char* pcmd);
void freeAs();

hist *firstH;//the first index of history
hist *currentH;//the current index of history
as *firstAs;
as *currentAs;
