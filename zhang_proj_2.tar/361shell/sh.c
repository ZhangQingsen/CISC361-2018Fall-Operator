#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <limits.h>
#include <unistd.h>
#include <stdlib.h>
#include <pwd.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include "sh.h"

int sh(int argc, char **argv, char **envp) {

	setvbuf(stdout, NULL, _IONBF, 0); //let buffer be NULL

	char *prompt = calloc(PROMPTMAX, sizeof(char));
	char *commandline = calloc(MAX_CANON, sizeof(char));
	char *command, *arg, *commandpath, *p, *pwd, *owd;
	char **args = calloc(MAXARGS, sizeof(char*));
	int uid, i, status, argsct, go = 1;
	struct passwd *password_entry;
	char *homedir;

	uid = getuid();
	password_entry = getpwuid(uid); /* get passwd info */
	homedir = password_entry->pw_dir; /* Home directory to start out with*/

	if ((pwd = getcwd(NULL, PATH_MAX + 1)) == NULL) {
		perror("getcwd");
		exit(2);
	}
	owd = calloc(strlen(pwd) + 1, sizeof(char));
	memcpy(owd, pwd, strlen(pwd));
	prompt[0] = ' ';
	prompt[1] = '\0';

	prompt = "[cisc361]";

	/* Put PATH into a linked list */
	pathlist = get_path();

	int size = 100;

	firstH = malloc(sizeof(hist));
	firstH->cmdline = malloc(size * sizeof(char));
	firstH->cmdline = "History:\n";
	firstH->next = NULL;
	currentH = firstH;

	currentAs = firstAs;

	while (go) {
		/* print your prompt */
		printf("%s$ ", prompt);
		for (int i = 0; i < MAXARGS; i++) {
			args[i] = NULL;
		} //for - initialize args, history
		command = malloc(size * sizeof(char));
		fgets(command, size, stdin);
		if (command[strlen(command)-1] == '\n')
			command[strlen(command)-1] = '\0';
		while (strlen(command) == 0) {
			printf("\n%s$ ", prompt);
			fgets(command, size, stdin);
			if (command[strlen(command)-1] == '\n')
				command[strlen(command)-1] = '\0';
		}

		int i = 0;
		args[i] = malloc(size * sizeof(char));
		args[i] = strtok(command, " ");
		while(args[i] != NULL){
			i++;
			args[i] = malloc(size * sizeof(char));
			args[i] = strtok(command, " ");
		}






		hist *tempH = malloc(sizeof(hist));
		tempH->cmdline = malloc(sizeof(command));
		strcpy(tempH->cmdline, command);
		tempH->next = NULL;
		currentH->next = tempH;
		currentH = currentH->next;

		args[0] = strtok(command, " ");
		//------------check alias-------------------------
		int j = 1;
		as *tempAs = firstAs;
		while (tempAs != NULL) {
			if (strcmp(tempAs->cmd, command) == 0) {
				tempAs->cmdline;
				char *tempChar = malloc(100 * sizeof(char));
				strcpy(tempChar, args[0]);
				args[0] = tempAs->cmdline;
				args[1] = strtok(args[0], " ");
				j += (args[1] == NULL) ? 0 : 1;
				break;
			}
			tempAs = tempAs->next;
		}

		//-------------------get commands---------------

		/* get command line and process */
		int b = 0; //flag
		commandpath = (which(command));
		if (commandpath != NULL) {
			commandpath = strcat(commandpath, command);
		}
		if(strcmp(command, "exit") == 0){
			for (int i = 0; i < MAXARGS; i++) {
				free(args[i]);
			} //for - free args
			free(args);
			void freeAs();
			void freeHist();
			return 0;
		}
		b = (!strcmp(command, "which"))?1:
				(!strcmp(command, "where"))?2:
						(!strcmp(command, "list"))?3:
								(!strcmp(command, "cd"))?4:
										(!strcmp(command, "pwd"))?5:
												(!strcmp(command, "printenv"))?6:
														(!strcmp(command, "setenv"))?7:
																(!strcmp(command, "alias"))?8:
																		(!strcmp(command, "prompt"))?9:0;
		if (b != 0) {
			printf("Executing built-in [%s]", command);
			switch (b) {
			case 1: {
				commandpath = which(args[1]);
				printf("%s\n", commandpath);
			}
				break;
			case 2:
				where(args[0]);
				break;
			case 3:
				list(args[0]);
				break;
			case 4:
				my_cd(args[0]);
				break;
			case 5:
				my_pwd();
				break;
			case 6:
				my_printenv(args);
				break;
			case 7:
				my_setenv(args);
				break;
			case 8:
				creatAs(args[0]);
				break;
			case 9:
				strcpy(prompt, args[0]);
				break;
			}
		} else if (access(commandpath, X_OK) == 0) {
			printf("Executing [%s]", commandpath);
			execF(args, commandpath, envp);
		} else if (access(args[0], X_OK) == 0) {
			printf("Executing [%s]", args[0]);
			execF(args, commandpath, envp);
		} else
			fprintf(stderr, "%s: Command not found.\n", args[0]);

		/* check for each built in command and implement */
		{
			/*  else  program to exec */
			/* find it */
			/* do fork(), execve() and waitpid() */

		}

/*		for (int k = 0; k < i; k++) {
			free(args[k]);
		} //for - free args*/
		free(command);
	}		  //while

	free(args);
	void freeAs();
	void freeHist();
	return 0;
} /* sh() */

char *which(char *command){
	/* loop through pathlist until finding command and return it.  Return
	 NULL when not found. */
	char *temp = calloc(PROMPTMAX, sizeof(char));
	while (pathlist != NULL) {
		temp = pathlist->element;
		if (strcmp(command, temp) == 0) {
			//printf("%s\n", temp);
			return temp;
		}
		pathlist = pathlist->next;
	} //while

	printf("[%s] not found\n", command);
	return NULL;
} /* which() */

void where(char *command){
	/* similarly loop through finding all locations of command */
	char *temp = calloc(PROMPTMAX, sizeof(char));
	int count = 0;
	while (pathlist != NULL) {
		temp = pathlist->element;
		if (strcmp(command, temp) == 0) {
			printf("%s\n", temp);
			count++;
		}
		pathlist = pathlist->next;
	} //while
	if (count == 0)
		printf("[%s] not found\n", command);
} /* where() */

void list(char *dir) {
	/* see man page for opendir() and readdir() and print out filenames for
	 the directory passed */
	typedef struct __dirstream DIR;
	DIR *dp;
	struct dirent *dirp;
	struct dirent *rent; //struct
	dp = (dir == NULL) ? opendir(".") : opendir(dir);
	while ((dir = readdir(dp)) != NULL) {
		printf("%s\n", dirp->d_name);
	}

	closedir(dp);

} /* list() */

void my_printenv(char **envp) {
	struct pathelement * tempPL = pathlist;
	while (tempPL != NULL) {
		char * str1 = tempPL->element;
		if (envp != NULL) {
			int i = 0;
			while (envp[i] != NULL) {
				i++;
				if (cmpWithWildCard(str1, envp[i]) == 0) {
					printf("%s\n", str1);
				}
			} //inner while
		} //if
		tempPL = tempPL->next;
	} //outer while
}

void my_setenv(char **envp) {
	free_env();
	struct pathelement * tempPL = pathlist;
	tempPL = malloc(sizeof(struct pathelement));
	tempPL->element = malloc(sizeof(struct pathelement));
	strcpy(tempPL->element, envp[0]);
	tempPL->next = NULL;
	int i = 1;
	while (envp[i] != NULL) {
		tempPL->next = malloc(sizeof(struct pathelement));
		tempPL = tempPL->next;
		tempPL->element = malloc(sizeof(struct pathelement));
		strcpy(tempPL->element, envp[0]);
		tempPL->next = NULL;
		i++;
	}
}

void free_env() {
	while (pathlist != NULL) {
		free(pathlist->element);
		struct pathelement * tempPL = pathlist;
		pathlist = pathlist->next;
		free(tempPL);
	}
}

void my_cd(const char *cd_to) {
	chdir(cd_to);
} //my_cd

char * my_pwd(){
	char strbuffer[512];
	memset(strbuffer, 0, sizeof(strbuffer));
	getcwd(strbuffer, sizeof(strbuffer));
	printf("%s\n", strbuffer);
	return strbuffer;
} //my_pwd

void printHist(int size) {
	hist * temp = firstH;
	int i = 0;
	while (temp != NULL && i < size) {
		printf("%s\n", temp->cmdline);
		temp = temp->next;
	}
}

void freeHist() {
	while (firstH != NULL) {
		free(firstH->cmdline);
		hist * temp = firstH;
		firstH = firstH->next;
		free(temp);
	}
}

void execF(char** args, char *path, char **envp) {
	pid = fork();
	if (pid == 0) {
		execve(path, args, envp);
	} else {
		waitpid(pid, 0, NULL);
	}
}

int cmpWithWildCard(char *str1, char *str2) {
	int result = strcmp(str1, str2);
	return result;
}

void creatAs(char* pcmd) {
	char* pcmdline = malloc(100 * sizeof(char));
	pcmdline = strtok(pcmd, "=");
	as *tempAs = firstAs;
	as *tempAsPrev = tempAs;
	while (tempAs != NULL) {
		if (strcmp(pcmd, tempAs->cmd) == 0) {
			tempAs->cmdline = pcmdline;
			free(pcmdline);
			return;
		}
		tempAsPrev = tempAs;
		tempAs = tempAs->next;
	}

	as *result = malloc(sizeof(as));
	result->cmd = malloc(sizeof(pcmd));
	strcpy(result->cmd, pcmd);
	result->cmdline = malloc(sizeof(pcmdline));
	strcpy(result->cmdline, pcmdline);
	result->next = NULL;
	if (firstAs == NULL) {
		firstAs = result;
	} else {
		tempAsPrev->next = result;
	}
	free(pcmdline);
}

void freeAs() {
	while (firstAs != NULL) {
		free(firstAs->cmd);
		free(firstAs->cmdline);
		as * tempAs = firstAs;
		firstAs = firstAs->next;
		free(tempAs);
	}
}
