#include <stdio.h>
#include <dirent.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

char buff[4096];
int len;
int myCopy(char const *s1, char const *s2);

int main(int argc, char const *argv[]){

	// Check for 2 arguments
	if (argc != 3) {        // a bug here!
		printf("ERROR: Need exactly two arguments.\n");
		exit(-1);
	}

	char const *src_path = argv[1];
	char const *des_path = argv[2];
	myCopy(src_path, des_path);
	return 0;
}//main

//myCopy char* char* -> int
//Consumes: char* s1: path of file1
//			char* s2: path of file2
//Produces: int: 0 if copy success, -1 if problem
int myCopy(char const *s1, char const *s2){
	int result = -1;
	if(access(s1, R_OK) !=0 ){
		printf("cannot read %s\n", s1);
		exit(result);
	}
	int fd = open(s1, O_RDONLY);
	int fd2 = open(s2, O_WRONLY|O_CREAT);
	
	//printf("Access-%d\n", access(s2, W_OK));

//	if(fd2 != 0){
//		printf("Open-%d: Cannot write %s\n",fd2, s2);
//		exit(result);
//	}//if

	while(len = read(fd,buff,1024)){
		int i =write(fd2,buff,len);
//		printf("%d/n", i);
//		printf("%s\n", buff);

	}//while

	 close(fd);
	 close(fd2);
	return 0;
}//myCopy



