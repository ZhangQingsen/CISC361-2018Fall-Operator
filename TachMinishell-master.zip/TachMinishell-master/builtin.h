#ifndef _BUILTIN_H_
#define _BUILTIN_H_

int builtin(void);
#endif /* _BUILTIN_H_ */
