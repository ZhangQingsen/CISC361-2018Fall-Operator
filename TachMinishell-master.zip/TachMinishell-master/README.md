# TachMinishell
Linux下shell的实现
------

    1. 支持ls,touch,wc 等外部命令
    2. 支持输入输出重定向符
    3. 支持管道命令
    4 .支持后台作业
    5. 支持cd,jobs,kill,exit等内部命令（自己还写了一个about 命令 ^ _ ^）
    6. 支持对ctrl+c 和ctrl +z 信号的处理
    
    详细步骤请参考我的博客  http://blog.csdn.net/nk_test/article/details/49851943
    
    欢迎大家帮助修改，有问题请联系 acm_tach@163.com
    
