#ifndef MP3_H_
#define MP3_H_

#include <stdio.h>
#include<stdlib.h>
#include <string.h>


typedef struct mp3{
	char *artist;
	char *title;
    int date;
	int timelong;
	struct mp3 *prev;
    struct mp3 *next;
} mp3;

mp3 *first, *last;

mp3* createMp3();
void delMp3(mp3 *m);
void printMp3(mp3 *m);
void printInOrder();
void printReverse();
void delArtist();
void delAll();
int printIntro();
void executeCmd(int i);

#endif /* MP3_H_ */
