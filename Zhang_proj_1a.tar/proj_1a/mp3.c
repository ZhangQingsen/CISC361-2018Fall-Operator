#include<stdio.h>
#include<stdlib.h>
#include "mp3.h"


//createMp3 : void -> mp3*
//consumes: void : nothing, all the inputs are from keyboard
//Produces: mp3* : the address of a mp3 object
mp3* createMp3(){
	int size = 200;

	char strN[size], strT[size], strD[size], strL[size];
	printf("Please input information about added mp3:\nname: ");
	fgets(strN, size, stdin);
	printf("title: ");
	fgets(strT, size, stdin);
	printf("date: ");
	fgets(strD, size, stdin);
	printf("timelong(in sec): ");
	fgets(strL, size, stdin);


	mp3 *result = malloc(sizeof(mp3)+100);
	if(result == NULL){
		printf("aaaaaaaaaa");
	}else{
		result->artist = malloc(sizeof(strN));
		result->title = malloc(sizeof(strT));
		strcpy(result->artist, strN);
		strcpy(result->title, strT);
		result->date = atoi(strD);
		result->timelong = atoi(strL);
		result -> prev = NULL;
		result -> next = NULL;

		printMp3(result);
	}
	return result;
}//createMp3

//delMp3 : mp3* -> void
//consumes: mp3* m: a given address of mp3
//Produces:  void: produces nothing but free this mp3
void delMp3(mp3 *m){
	mp3 *tempP = m -> prev;
	mp3 *tempN = m -> next;

	if(first == m)
		first = tempN;

	if(last == m)
		last = tempP;

	if (tempN != NULL)
		tempN->prev = tempP;

	if (tempP != NULL)
		tempP->next = tempN;
	free(m);

}//delMp3

//printMp3 : mp3* -> void
//consumes: mp3* m: a given address of mp3
//Produces:  void: produces nothing but print this mp3
void printMp3(mp3 *m){
	int d = m -> date;
	int year = d % 100;
	d /= 100;
	int month = d % 100;
	d /= 100;
	printf("%s's %s", m->artist, m->title);
	printf("%d/%d/%d\n%d\r\n", d, month,year,m->timelong);
}//printMp3

//printInOrder : mp3* -> void
//consumes: void: the address of the first mp3 in this list
//Produces:  void: produces nothing but print these mp3s
void printInOrder(){
	int count = 0;
	mp3 *temp = first;
	while(temp != NULL){
		count++;
		printMp3(temp);
		temp = temp->next;
	}//while
	printf("All %d mp3's are printed\n\n", count);
}//printInOrder

//printReverse : mp3* -> void
//consumes: void: the address of the last mp3 in this list
//Produces:  void: produces nothing but print these mp3s
void printReverse(){
	int count = 0;
	mp3 *temp = last;
	while(temp != NULL){
		count++;
		printMp3(temp);
		temp = temp->prev;
	}//while
	printf("All %d mp3's are printed\n", count);
}//printReverse

//delArtist : mp3* -> void
//consumes: void: the address of the first mp3 in this list
//Produces:  void: produces nothing but deletes all mp3 of the given artist
void delArtist(){
	char str[200];
	printf("please enter the artist:");
	fgets(str, 100, stdin);
	int count = 0;
	mp3 *temp = first;
	while(temp != NULL){
		int flag = strcmp(str, temp->artist);
		mp3 *temp1 = temp->next;
		if(flag == 0){
			count++;
			delMp3(temp);
		}//if
		temp = temp1;
	}//while
	printf("All %d %s's mp3's are removed\n", count, str);
}//delArtist

//delAll : mp3* -> void
//Consumes: void: the address of the first mp3 in this list
//Produces: void produces nothing but deletes all mp3 in this list
void delAll(){
	int count = 0;
	mp3 *temp = first;
	while(temp != NULL){
		mp3 *temp1 = temp->next;
		count++;
		delMp3(temp);
		temp = temp1;
	}//while
	printf("All %d mp3's are removed\n", count);
}//delAll
