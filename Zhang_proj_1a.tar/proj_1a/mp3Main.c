#include <stdio.h>
#include<stdlib.h>
#include "mp3.h"


int main(int argc, char *argv[]){
	setvbuf(stdout,NULL,_IONBF,0);//let buffer be NULL
//	printf("Hello, world!\n");
	int i = printIntro();
	while(i <= 5){
		executeCmd(i);
		i = printIntro();
	}//while
	return 0;
}//main

//printIntro void -> void
//Consumes: void : consumes nothing
//Produces: int : print the instructions
//			and reads the input, return the int as command
int printIntro(){
	printf("(1) add an MP3 to the list\n"
			"(2) delete MP3(s) from the list\n"
			"(3) print the list from beginning to end\n"
			"(4) print the list from end to beginning\n"
			"(5) exit the program\n");
	char c;
	c = getchar();
	getchar();
	int i = c - '0';
	return i;
}//printIntro

//executeCmd void -> void
//Consumes: int i : the command
//Produces: void : follows the instruction, puts nothing
void executeCmd(int i){
	switch(i){
	case 1:{mp3* temp = createMp3();
		if(first == NULL){
			first = temp;
			last = first;
		}else{last -> next = temp;
		temp->prev = last;
		last = temp;}//if-else
	}break;
	case 2:delArtist(first);break;
	case 3:printInOrder(first);break;
	case 4:printReverse(last);break;
	case 5:{delAll(first);
	exit(0);}break;
	}//switch
}//executeCmd
